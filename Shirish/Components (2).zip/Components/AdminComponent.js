import React from "react";

import { Link, Route, Routes } from "react-router-dom";
import PendingReq from "./PendingReq";


function AdminComp(){
    return(
        <div class="col-md-4 ">
        <nav className="navbar navbar-expand-md navbar-light bg-light sidebar">
          
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#leftNavbar"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
    
          
          <div className="collapse navbar-collapse" id="leftNavbar">
            <ul className="navbar-nav flex-column">
            
         
      <li className="nav-item">
        <Link to="/pendingrequest" className="nav-link px-3">Pending Request</Link>
      </li>
     
           </ul>
          </div>
         <div>
              <Routes>
               <Route path='pendingrequest' element={<PendingReq/>}/>
               {/*  <Route path='partlist' element={<PartListComp/>}/>
                <Route path="rawmateriallist" element={<RawMaterialListComp/>}/>
                <Route path="machinelist" element={<MachineListComp/>}/>
                <Route path="vendors" element={<VendorComp/>}/> */}
              </Routes>
              
              </div> 

    </nav>

        </div>
    );
}
export default AdminComp;