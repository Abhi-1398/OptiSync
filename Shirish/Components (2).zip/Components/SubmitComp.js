import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Submit()
{
    const[submit,setsubmit]=useState([])
    useEffect(() => {
         const submit=JSON.parse(localStorage.getItem('submit'));
        if (submit) {
         setsubmit(submit);
        }
      }, []); 
      const navigate = useNavigate();
      const returntologin=()=>{
        navigate("/Login")
      }
    return(
        <div>
             <h1>Thank You For Registration We will contact you on {submit.contact_no} and send all login Id's on {submit.email}</h1>
             <button type="button" onClick={returntologin}>Return to Login</button>
        </div>





    )
   
}