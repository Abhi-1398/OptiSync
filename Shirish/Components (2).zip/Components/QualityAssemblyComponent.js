import React from "react";

function QualityAssemblyComp(){
    return(
        <div>
            <h1>QualityAssembly</h1>
        </div>
    )
}
export default QualityAssemblyComp;