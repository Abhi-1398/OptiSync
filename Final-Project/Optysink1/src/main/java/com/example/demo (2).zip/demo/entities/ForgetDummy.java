package com.example.demo.entities;

public class ForgetDummy {
	String username;
	String mname;
	public ForgetDummy(String username, String mname) {
		super();
		this.username = username;
		this.mname = mname;
	}
	public ForgetDummy() {
		super();
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	
	

}
