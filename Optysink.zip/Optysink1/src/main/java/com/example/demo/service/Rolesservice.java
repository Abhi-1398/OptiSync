package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entities.Roles;
import com.example.demo.repository.Rolesreposirory;

@Service
public class Rolesservice {
	@Autowired
	Rolesreposirory rrep;
	
	public List<Roles> getAll()
	{
		return rrep.findAll();
	}
	public Roles saveRole(@RequestBody Roles rt)
	{
		return rrep.save(rt);
	}

}
