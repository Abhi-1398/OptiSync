function HomeComponent(){
    return(
        <div>
             <h3>
        OptiSync allows management to check status for the current orders being executed, raw material entered in vicinity<br/>
         of the company is digitalized
          and will help overall stock analysis.<br/>
          Tracing of the parts in production is made easy with detail report of the parts being produced.<br/>
           Data generated in quality control for manufactured product is monitored with help of our application.<br/> 
           Our application will help to track delivery and dispatch of the products manufactured.<br/>
            To help achieve this we have different modules such as manager, vendor, storage, production, assembly, quality and dispatch. 
        </h3>
        </div>
    );
}
export default HomeComponent;