import React from "react";

function VendorComp(){
    return(
        <div>
            <h1>Vendor</h1>
        </div>
    )
}
export default VendorComp;