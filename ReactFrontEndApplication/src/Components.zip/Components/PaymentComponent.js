import React from "react";
function PaymentComp(props)

{
    console.log(JSON.stringify(props))
    return(
        <div>
            <h1>Payment component</h1>
        </div>
    )
}

export default PaymentComp;