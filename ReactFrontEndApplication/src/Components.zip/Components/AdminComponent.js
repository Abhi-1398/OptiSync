import React from "react";

function AdminComp(){
    return(
        <div>
            <h1>Admin</h1>
        </div>
    )
}
export default AdminComp;