export default function LoginComp()
{
    return (<div>
        <h1>Login page</h1>
        <form>
            Enter Uid:
            <input type="Text" />
            <input type="submit" value="Submit"></input>



        </form>

    </div>
    
    
    
    
)
}