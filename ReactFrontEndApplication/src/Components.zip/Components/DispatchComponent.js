import React from "react";

function DispatchComp(){
    return(
        <div>
            <h1>Dispatch</h1>
        </div>
    )
}
export default DispatchComp;