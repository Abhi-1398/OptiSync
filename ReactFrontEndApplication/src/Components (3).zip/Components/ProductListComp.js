import React, { useEffect, useReducer, useState } from "react";
import { useNavigate } from "react-router-dom";
 
export default function ProductListComp() {

  /* const [loggedUser,setallPlan] = useState([]);
    useEffect(() => {
        const loggedUser = (JSON.parse(localStorage.getItem('loggedUser')).company)
        console.log()
        if (loggedUser) {
         setallPlan(loggedUser);
        }
      }, []); */
    
const navigate=useNavigate();

    const initialState={
    product_name:"",
    product_description:"",
    company_id:(JSON.parse(localStorage.getItem('loggedUser')).company).company_id

  }

const reducer = (state, action) => {
  switch(action.type) {
       case 'update':
          return {...state, [action.fld]:action.val }
       case 'reset':
          return initialState
  }

}

const[formData, dispatch] = useReducer(reducer , initialState );

const sendData = (e) => {
  e.preventDefault();

  const reqOption = {
   method:'POST',
   headers:{'content-type':'application/json'},
   body: JSON.stringify(formData)
  }

  fetch("http://localhost:8080/saveProducts",reqOption)
  .then(resp => {if(resp.ok)
   return resp.text();
  else
   throw new Error("server error");
  })
  .then(text => text.length ? JSON.parse(text) : {})
  .catch((Error)=>alert("server error . try again later")) 
  console.log(formData) ;
  navigate('/Setup');

}

  return (
    <div>
      <h1>Product Details</h1>
      <div className="mb-2">
        <div className="form-row">
          <label htmlFor="product_name">Product name:</label>
          <input type="text" name="product_name" className="form-control" id="product_name" value={formData.product_name}
          onChange={(e)=>{dispatch({type:'update',fld:'product_name',val:e.target.value})}} required />
                 
        </div>

        <div className="mb-2">
          <label htmlFor="product_description">Description:</label>
          <input
            type="textarea"
            name="product_description"
            className="form-control"
            id="product_description"
            value={formData.product_description}
                    onChange={(e)=>{dispatch({type:'update',fld:'product_description',val:e.target.value})}} required />
         
        </div>
      </div>

      <div className="submit-button-container">
            <button type="submit" onClick={(e)=>sendData(e)}>Submit</button>
            <button type="reset"  onClick={()=>{dispatch({type:'reset'})}}>Clear</button>
          </div>

<p>{JSON.stringify(formData)}</p>
    </div>
  );
}
