import React from "react";

function StoreComp(){
    return(
        <div>
            <h1>Storage</h1>
        </div>
    )
}
export default StoreComp;