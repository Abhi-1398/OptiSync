import React from "react";

function VendorComp1(){
    return(
        <div>
            <h1>Vendor</h1>
        </div>
    )
}
export default VendorComp1;