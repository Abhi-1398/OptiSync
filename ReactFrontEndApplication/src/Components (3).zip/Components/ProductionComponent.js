import React from "react";

function ProductionComp(){
    return(
        <div>
            <h1>Production</h1>
        </div>
    )
}

export default ProductionComp;